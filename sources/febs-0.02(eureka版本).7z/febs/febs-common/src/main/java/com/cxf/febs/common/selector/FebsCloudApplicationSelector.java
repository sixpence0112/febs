package com.cxf.febs.common.selector;

import com.cxf.febs.common.configure.FebsAuthExceptionConfigure;
import com.cxf.febs.common.configure.FebsOAuth2FeignConfigure;
import com.cxf.febs.common.configure.FebsServerProtectConfigure;
import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.type.AnnotationMetadata;

/**
 * @author sixpence
 * @version 1.0 2020/10/9
 */
public class FebsCloudApplicationSelector implements ImportSelector {

    @Override
    public String[] selectImports(AnnotationMetadata annotationMetadata) {
        return new String[] {
                FebsAuthExceptionConfigure.class.getName(),
                FebsServerProtectConfigure.class.getName(),
                FebsOAuth2FeignConfigure.class.getName()
        };
    }
}
